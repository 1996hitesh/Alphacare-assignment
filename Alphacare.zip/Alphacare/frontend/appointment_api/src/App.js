import React, { useEffect, useState } from 'react';
import './App.css';
import Appointments from './components/appointments/appointment'
import AppointmentLoadingComponent from './components/appointments/appointmentLoading';
import axiosInstance from './axios';

function App() {
	const AppointmentLoading = AppointmentLoadingComponent(Appointments);
	const [appState, setAppState] = useState({
		loading: false,
		appointments: null,
	});

	useEffect(() => {
		axiosInstance.get().then((res) => {
			const allAppointments = res.data;
			setAppState({ loading: false, appointments: allAppointments });
			console.log(res.data);
		});
	}, [setAppState]);
	return (
		<div className="App">
			<h1>Latest Appointments</h1>
			<AppointmentLoading isLoading={appState.loading} appointments={appState.appointments} />
		</div>
	);
}
export default App;
