import React, { useEffect, useState } from 'react';
import './App.css';
import Appointments from './components/admin/appointments';
import AppointmentLoadingComponent from './components/appointments/appointmentLoading';
import axiosInstance from './axios';

function Admin() {
	const AppointmentLoading = AppointmentLoadingComponent(Appointments);
	const [appState, setAppState] = useState({
		loading: true,
		appointments: null,
	});

	useEffect(() => {
		axiosInstance.get().then((res) => {
			const allAppointments = res.data;
			setAppState({ loading: false, appointments: allAppointments });
			console.log(res.data);
		});
	}, [setAppState]);

	return (
		<div className="App">
			<h1>Latest Appointment</h1>
			<AppointmentLoading isLoading={appState.loading} appointments={appState.appointments} />
		</div>
	);
}
export default Admin;
