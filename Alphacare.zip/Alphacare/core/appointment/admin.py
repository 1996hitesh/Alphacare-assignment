from django.contrib import admin
from . import models


@admin.register(models.Appointment)
class AuthorAdmin(admin.ModelAdmin):
    list_display = ('problem', 'id', 'slug', 'author')
    prepopulated_fields = {'slug': ('problem',), }


