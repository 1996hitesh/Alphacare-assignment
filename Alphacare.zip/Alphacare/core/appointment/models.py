from django.db import models
from django.utils import timezone
from django.conf import settings


class Appointment(models.Model):

    problem = models.CharField(max_length=250)
    details = models.TextField()
    appointment_date = models.DateField(auto_now=False, auto_now_add=False)
    slug = models.SlugField(max_length=250, unique_for_date='published')
    published = models.DateTimeField(default=timezone.now)
    author = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='blog_posts')
    
    objects = models.Manager()  # default manager

    class Meta:
        ordering = ('-published',)

    def __str__(self):
        return self.problem
