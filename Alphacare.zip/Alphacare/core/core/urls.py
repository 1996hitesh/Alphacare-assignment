from django.contrib import admin
from django.urls import path, include
from rest_framework.schemas import get_schema_view
from rest_framework.documentation import include_docs_urls
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)

urlpatterns = [
    #API Token Management
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    #Project URLs
    path('admin/', admin.site.urls),
    path('', include('appointment.urls', namespace='appointment')),
    # User Management
    path('api/user/', include('users.urls', namespace='users')),
    # Blog_API Application
    path('api/', include('appointment_api.urls', namespace='appointment_api')),

    # API schema and Documentation
    path('project/docs/', include_docs_urls(title='AppointmentAPI')),
    path('project/schema', get_schema_view(
        title="AppointmentAPI",
        description="API for the AppointmentAPI",
        version="1.0.0"
    ), name='openapi-schema'),]
