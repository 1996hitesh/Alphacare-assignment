from django.apps import AppConfig


class AppointmentApiConfig(AppConfig):
    name = 'appointment_api'
