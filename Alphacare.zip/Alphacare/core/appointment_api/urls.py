from django.urls import path
from .views import AppointmentList, AppointmentDetail, AdminAppointmentDetail, EditAppointment, CreateAppointment, DeleteAppointment, AppointmentListDetailfilter
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)


app_name = 'appoinment_api'

urlpatterns = [
    path('', AppointmentList.as_view(), name='appointment'),
    path('appointment/<str:pk>/', AppointmentDetail.as_view(), name='detailappointment'),
    path('search/', AppointmentListDetailfilter.as_view(), name='searchappointment'),
    # Post Admin URLs
    path('admin/create/', CreateAppointment.as_view(), name='createappointment'),
    path('admin/edit/postdetail/<int:pk>/', AdminAppointmentDetail.as_view(), name='admindetailappointment'),
    path('admin/edit/<int:pk>/', EditAppointment.as_view(), name='editappointment'),
    path('admin/delete/<int:pk>/', DeleteAppointment.as_view(), name='deleteappointment'),
]
